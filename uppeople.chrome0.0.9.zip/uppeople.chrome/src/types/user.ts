export interface User {
  id: number;
  name: string;
  email: string;
  isdel: boolean;
  roleId: number;
  lastLogin: string;
  lastIp: string;
  // hash: 0;
  // last_page: null;
  // address: string;
  // emailpool: null;
  phone: string;
  // languages: null;
  // id_homepages: 0;
  createat: 'string';
  // companies: {};
  password: string;
  accessToken: string;
}
