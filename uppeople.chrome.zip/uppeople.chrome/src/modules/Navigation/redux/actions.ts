import { action } from 'redux-burger-menu';

export const toggleMenu = action;
