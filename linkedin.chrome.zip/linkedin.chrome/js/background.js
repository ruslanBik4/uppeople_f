chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tabs) {
        // chrome.storage.local.set({candidate: null});
        let url_match = decodeURIComponent(tabs.url).match('https:\/\/www.linkedin.com\/in\/[a-zа-яії0-9-]*\/');
        if (url_match !== null) {
            if (changeInfo.status === 'loading') {
                // if (changeInfo.status === 'complete') {
                check(url_match[0]);
            }
        }
    }
);

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    switch (msg.command) {
        case "update_candidate":
            let result = AJAXJson('/api/main/addNewCandidate', msg.data);
            break;
        case "update_selector":
            AJAX('/api/update_selector', 'name=' + msg.name + '&selector=' + encodeURIComponent(msg.new_selector) + '&type=' + msg.type);
            break;
        case "authorize":
            AJAXJson('/api/auth/login', msg.data);
            break;
        case "new_url":
            check(msg.url);
    }
});

const api_url = 'https://161.97.144.240';
let xhttp = new XMLHttpRequest();

function AJAXJson(api, data) {

    xhttp.open("POST", api_url + api, true);
    if (data.token > "") {
        xhttp.setRequestHeader('Authorization', 'Bearer ' + data.token)
    }
    xhttp.setRequestHeader('Content-Type', 'application/json');
    delete data.token;
    let body = JSON.stringify(data);
    xhttp.onreadystatechange = function () {
        if (this.readyState !== 4) {
            return
        }
        if (this.status === 200) {
            let result = JSON.parse(this.responseText);
            chrome.storage.local.set({
                ajax_result: {
                    status: 'ok',
                    message: result.message,
                    result: result,
                    api: api
                }
            });
        } else if (this.status === 400) {
            let data = JSON.parse(this.responseText);
            chrome.storage.local.set({
                ajax_result: {
                    status: this.status,
                    formErrors: data.formErrors,
                    api: api
                }
            });
        } else if (this.status === 401) {
            chrome.storage.local.set({
                ajax_result: {
                    status: this.status,
                    api: api
                }
            });
        } else {
            chrome.storage.local.set({
                ajax_result: {
                    status: this.status,
                    result: this.responseText,
                    api: api
                }
            });
        }
    }
    xhttp.send(body)
}

function AJAX(api, param) {

    chrome.storage.local.set({
        ajax_result: null
    });
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", api_url + api, true);
    xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded', 'Set-Cookie: cross-site-cookie=name; SameSite=Strict; Secure');
    xhttp.onreadystatechange = function () {
        if (this.readyState !== 4) {
            return
        }
        if (this.status === 200) {
            switch (api) {
                case '/api/auth/login':
                    chrome.storage.local.set({
                        ajax_result: {
                            status: 'ok',
                            result: JSON.parse(this.responseText),
                            api: api
                        }
                    });
                    break;

                case '/api/get_platforms':
                    chrome.storage.local.set({platforms: JSON.parse(this.responseText).status});
                    break;

                case '/api/get_seniorities':
                    chrome.storage.local.set({seniorities: JSON.parse(this.responseText).status});
                    break;

                case '/api/get_tags':
                    chrome.storage.local.set({tags: JSON.parse(this.responseText).status});
                    break;

                case '/api/get_reasons':
                    chrome.storage.local.set({reasons: JSON.parse(this.responseText).status});
                    break;

                case '/api/get_recruiter_vacancies':
                    chrome.storage.local.set({vacancies: JSON.parse(this.responseText).vacancies});
                    break;

                case '/api/get_selectors':
                    chrome.storage.local.set({selectors: JSON.parse(this.responseText).data});
                    break;

                case '/api/get_candidate_info':
                    chrome.storage.local.set({candidate: JSON.parse(this.responseText)});
                    let result_ = JSON.parse(this.responseText);
                    chrome.storage.local.set({
                        ajax_result: {
                            status: result_.status,
                            result: result_,
                            api: api
                        }
                    });
                    break;

                default:
                    let result = JSON.parse(this.responseText);
                    chrome.storage.local.set({
                        ajax_result: {
                            status: result.status,
                            result: JSON.parse(this.responseText),
                            api: api
                        }
                    });
                    break;
            }
        } else if (this.status === 401) {
            open_popup()
        } else {
            console.log(this.response);
            chrome.storage.local.set({
                ajax_error: {
                    status: this.status,
                    result: this.responseText,
                    api: api
                }
            });

        }
    };

    xhttp.send(param);
}

function check(url_ = null) {
    let url = url_ !== null ? url_ : decodeURIComponent(window.location.href);
    chrome.tabs.query({currentWindow: true, active: true}, function (tab) {
        AJAX('/api/get_selectors', null);
        AJAX('/api/get_platforms', null);
        AJAX('/api/get_seniorities', null);
        AJAX('/api/get_tags', null);
        AJAX('/api/get_reasons', null);
        AJAX('/api/get_recruiter_vacancies', null);
        let url_match = url.match('https:\/\/www.linkedin.com\/in\/[a-zа-яії0-9-]*\/');
        if (url_match !== null) {
            AJAX('/api/get_candidate_info', 'url=' + url_match[0]);
        }
    });
}

function encodeQueryData(data) {
    const ret = [];
    for (let d in data)
        if (data[d] !== null && data[d].length > 0) {
            ret.push(encodeURIComponent(d) + '=' + encodeURIComponent(data[d]));
        }
    return ret.join('&');
}

