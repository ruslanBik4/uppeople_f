import * as actions from './actions';
import * as reducers from './reducers';

export const navigationActions = actions;
export const navigationReducers = reducers;
