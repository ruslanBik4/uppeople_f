export const GET_PATH_BY_SELECTOR = '__GET_PATH__';
