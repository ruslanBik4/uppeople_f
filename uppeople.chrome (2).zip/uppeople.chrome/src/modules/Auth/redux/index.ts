import * as actions from './actions';
import * as reducers from './reducers';

export const authActions = {
  user: actions.user,
};
export const authReducers = reducers;
